#include "sys.h"
#include "motor.h"


//IO��ģ��PWM
//int main(void)
//{
//	 MOTOR_Init();
//	 delay_init(72);	    //��ʱ������ʼ��	  
//	while(1)
//	{
//		PBout(6)=1;//pwm1
//		PBout(7)=0;//pwm2
//		PBout(8)=1;//pwm3
//		PBout(9)=0;//pwm4
//		delay_us(5000);
//		PBout(6)=0;//pwm1
//		PBout(7)=0;//pwm2
//		PBout(8)=0;//pwm3
//		PBout(9)=0;//pwm4
//		delay_us(5000);
//	}
//}

int main(void)
{
	 TIM4_PWM_Init(1000-1,720-1);  

	 while(1)
	 {
	
	motor_control(500,0,500,0);	 
	 }
}

