#include "redray.h"
u8 redray1_findblack;
u8 redray2_findblack;
u8 redray3_findblack;
u8 redray4_findblack;

void REDRAY_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);  
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOA, &GPIO_InitStructure);
}

void REDRAY_Scan(void)
{
	if(DO1==0)redray1_findblack=1;
	else redray1_findblack=0;
	if(DO2==0)redray2_findblack=1;
	else redray2_findblack=0;
	
}
