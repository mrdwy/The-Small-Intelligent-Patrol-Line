#ifndef __ENCODER_H
#define __ENCODER_H	 
#include "sys.h"

void encoder_Init(void);
void EXTIX_Init(void);

#endif
