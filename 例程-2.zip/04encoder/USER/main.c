#include "sys.h"

u8 key_value;
extern u8 redray1_findblack;
extern u8 redray2_findblack;
extern u8 redray3_findblack;
extern u8 redray4_findblack;

extern u16 RightWheelSpeedCount;
extern u16 LeftWheelSpeedCount;

int main(void)
{
	 EXTIX_Init();
	 LED_Init();
	 delay_init(72);	    //��ʱ������ʼ��	  
	 while(1)
	 {

		  if(RightWheelSpeedCount>10)
		  {
			   LED2=~LED2;
			   RightWheelSpeedCount=0;
		  }
			
		  if(LeftWheelSpeedCount>10)
		  {
			   LED1=~LED1;
			   LeftWheelSpeedCount=0;
		  }
	 }
}



