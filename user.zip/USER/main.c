#include "sys.h"
#include "stm32f10x.h"
#include "delay.h"
#include "led.h"
#include "key.h"
#include "redray.h"
#include "motor.h"
#include "encoder.h"


/*******************/
//findback��0��ʾ�ں�����
//led��1��ʾ��
u8 key_value;
extern u8 redray1_findblack_1;
extern u8 redray2_findblack_1;
extern u8 redray1_findblack_2;
extern u8 redray2_findblack_2;

extern u16 RightWheelSpeedCount;
extern u16 LeftWheelSpeedCount;

u8 key_value;
u16 delay=50;  //ת���ʱ��


int main(void)
{
	 delay_init(72);	    //��ʱ������ʼ��	  
	 LED_Init();   //LED��ʼ��
	 EXTIX_Init();
	 REDRAY_Init();//���ú���Թ���������
	 TIM4_PWM_Init(10000-1,72-1);  
	 while(1)
	 {

		 REDRAY_Scan();
			run();

/*****************/
/******������*****/
/*****************/		 
		 while(redray1_findblack_1==0&redray2_findblack_1==1)//��ת
		 {
			LED1=1;
			LED2=0;
			turn_left_s();
		 	REDRAY_Scan();
			 if(redray1_findblack_1==0&redray2_findblack_1==0){break ;}
		 }
/*****************/
/******������*****/
/*****************/
		 while(redray1_findblack_1==1&redray2_findblack_1==0)//��ת
		 {
			LED1=0;
			LED2=1;
			turn_right_s();
		 	REDRAY_Scan();
		  if(redray1_findblack_1==0&redray2_findblack_1==0){break ;}
		 }
/*****************/
/******����*******/
/*****************/	 
		if(redray1_findblack_1==1&redray2_findblack_1==1)//�������
			{
			 if(redray1_findblack_2==0&redray2_findblack_2==1)//��ת
			 {
				LED1=1;
				LED2=0;
				 while(redray1_findblack_1==1&redray2_findblack_1==1)
				 {
						turn_left_b();
						REDRAY_Scan();
						if(redray1_findblack_1==0&redray2_findblack_1==0){break ;}
				 }
			 }
			 
			 
			 
			 if(redray1_findblack_2==1&redray2_findblack_2==0)//��ת
			 {
				LED1=0;
				LED2=1;
				 while(redray1_findblack_1==1&redray2_findblack_1==1)
				 {
						turn_right_b();
						REDRAY_Scan();
						if(redray1_findblack_1==0&redray2_findblack_1==0){break ;}
					}
			 }
		}
	}

	}

	
//	
//	
//			  if(redray1_findblack_2==1&redray2_findblack_2==1)//ͣ��
//		 {
//			LED1=0;
//			LED2=1;
//			 run_stop();

//			 while(redray1_findblack_1==1&redray2_findblack_1==1)
//			 {
//			run_stop();
//		 	REDRAY_Scan();
//		  if(redray1_findblack_1==0&redray2_findblack_1==0){break ;}
//			}
//		 }		 
//			 
//			 if(redray1_findblack_2==0&redray2_findblack_2==0)//����
//			 {
//				LED1=1;
//				LED2=1;				 
//				run();
//				REDRAY_Scan();
//				
//			 }

