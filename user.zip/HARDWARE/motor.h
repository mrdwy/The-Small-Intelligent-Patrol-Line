#ifndef __MOTOR_H
#define __MOTOR_H	 
#include "sys.h"

void MOTOR_Init(void);//��ʼ��
void motor_control(u16 pwm1,u16 pwm2,u16 pwm3,u16 pwm4);
void TIM4_PWM_Init(u16 arr,u16 psc);
void turn_left_s(void);
void turn_right_s(void);
void turn_left_b(void);
void turn_right_b(void);
void run(void);
void run_stop(void);

#endif
