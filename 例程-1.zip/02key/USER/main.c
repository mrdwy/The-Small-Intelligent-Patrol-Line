#include "sys.h"

u8 key_value;

int main(void)
{
   LED_Init();
	 KEY_Init();
	 delay_init(72);	    //��ʱ������ʼ��	  

	 while(1)
	 {
		  key_value=KEY_Scan();
		  if(key_value==1)
		  {
			   LED1=1;
			   delay_ms(1000);
		  }
		  else LED1=0;
	 }
}



